package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;

public class ControllerVipClientOldLogin {
    VipClient a1 = new VipClient();

    @FXML
    public TextField txt1;
    @FXML
    public TextField txt2;
    @FXML
    public TextField txt3;
    @FXML
    public TextField txt4;
    @FXML
    public TextField txt5;

    @FXML
    public RadioButton rb1;
    @FXML
    public RadioButton rb2;

    @FXML
    Button bt1;
    @FXML
    Label lb5;
    @FXML
    CheckBox cb;

    @FXML
    public void fill(ActionEvent event) throws Exception
    {

        //String inputToFile1=this.name+","+this.ssn+","+this.address+","+this.phone+","+this.experience_years+","+this.workHours+","+this.present+","+this.numberOfAccountsOpened+","+this.numberOfTransactions+","+this.numberOfAccountsReviewed;
        //String name, int ssn, String address, String phone, int experience_years, int workHours, boolean present, int numberOfAccountsOpened, int numberOfTransactions, int numberOfAccountsReviewed) {
        try {
            a1.username=txt1.getText();
            a1.pinCode=Integer.parseInt(txt2.getText());
            a1.amount=Integer.parseInt(txt3.getText());
            if(rb1.isSelected())
                a1.WithDraw(a1.amount);
            else if(rb2.isSelected())
                a1.addToAccount(a1.amount);
            if(cb.isSelected()) {
                a1.PayLoan(a1.amount);
                txt4.setText(String.valueOf(a1.oldLoan));
            }
            else
                txt4.setText(String.valueOf(a1.oldLoan));
                txt5.setText(String.valueOf(a1.balance));
            //a1.editclient();


            lb5.setText("TRANSACTIONS DONE SUCCESFULLY");


        } catch(Exception e) {
            e.printStackTrace();
        }

    }





    }


